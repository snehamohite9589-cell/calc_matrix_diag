"use client";

import React from "react";
import { MathJax } from "better-react-mathjax";

interface ResultsDisplayProps {
  data: any;
}

export default function ResultsDisplay({ data }: ResultsDisplayProps) {
  if (data.error_msg) {
    return (
      <div className="mt-8 animate-fade-in">
        <div className="text-red-500 bg-red-500/10 border border-red-500/20 p-4 rounded-lg text-center mb-6">
          {data.error_msg}
        </div>
      </div>
    );
  }

  return (
    <div className="mt-8 animate-fade-in space-y-8">
      <div className="bg-slate-900/40 border border-white/5 p-6 rounded-xl">
        <h3 className="text-lg font-semibold text-cyan-500 mb-2">Input Matrix A</h3>
        <div className="text-xl overflow-x-auto py-4 text-center">
          <MathJax>{`\\[ A = ${data.matrix_latex} \\]`}</MathJax>
        </div>
      </div>

      <div className="bg-slate-900/40 border border-white/5 p-6 rounded-xl">
        <h3 className="text-lg font-semibold text-cyan-500 mb-2">1. Characteristic Equation</h3>
        <p className="text-slate-400 mb-4">Setting \(\det(A - \lambda I) = 0\):</p>
        <div className="text-xl overflow-x-auto py-4 text-center">
          <MathJax>{`\\[ ${data.char_eq_latex} \\]`}</MathJax>
        </div>
      </div>

      <div className="bg-slate-900/40 border border-white/5 p-6 rounded-xl">
        <h3 className="text-lg font-semibold text-cyan-500 mb-2">2. Eigenvalues</h3>
        <p className="text-slate-400 mb-4">Solving the characteristic equation for \(\lambda\):</p>
        <div className="text-xl overflow-x-auto py-4 text-center space-y-4">
          {data.eigenvals_latex.map((val: string, idx: number) => (
            <div key={idx}><MathJax>{`\\[ ${val} \\]`}</MathJax></div>
          ))}
        </div>
      </div>

      <div className="bg-slate-900/40 border border-white/5 p-6 rounded-xl">
        <h3 className="text-lg font-semibold text-cyan-500 mb-2">3. Eigenvectors</h3>
        <p className="text-slate-400 mb-4">{"Solving \\((A - \\lambda I)\\mathbf{v} = 0\\) for each eigenvalue:"}</p>
        <div className="text-xl overflow-x-auto py-4 text-center space-y-4">
          {data.eigenvects_latex.map((val: string, idx: number) => (
            <div key={idx}><MathJax>{`\\[ ${val} \\]`}</MathJax></div>
          ))}
        </div>
      </div>

      {data.is_diagonalizable && (
        <>
          <div className="bg-slate-900/40 border border-white/5 p-6 rounded-xl">
            <h3 className="text-lg font-semibold text-cyan-500 mb-2">4. Modal Matrix (P)</h3>
            <p className="text-slate-400 mb-4">Constructed by arranging the eigenvectors as columns:</p>
            <div className="text-xl overflow-x-auto py-4 text-center">
              <MathJax>{`\\[ P = ${data.P_latex} \\]`}</MathJax>
            </div>
          </div>

          <div className="bg-slate-900/40 border border-white/5 p-6 rounded-xl">
            <h3 className="text-lg font-semibold text-cyan-500 mb-2">5. Diagonalized Matrix (D)</h3>
            <p className="text-slate-400 mb-4">A diagonal matrix with the eigenvalues on the main diagonal:</p>
            <div className="text-xl overflow-x-auto py-4 text-center">
              <MathJax>{`\\[ D = ${data.D_latex} \\]`}</MathJax>
            </div>
          </div>

          <div className="bg-slate-900/40 border border-white/5 p-6 rounded-xl">
            <h3 className="text-lg font-semibold text-cyan-500 mb-2">6. Verification</h3>
            <p className="text-slate-400 mb-4">{"Verifying \\(A = P D P^{-1}\\) and \\(P^{-1} A P = D\\):"}</p>
            <div className="text-xl overflow-x-auto py-4 text-center space-y-4">
              {data.verification.map((step: string, idx: number) => (
                <div key={idx}><MathJax>{`\\[ ${step} \\]`}</MathJax></div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
