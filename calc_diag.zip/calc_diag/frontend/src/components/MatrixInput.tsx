"use client";

import React from "react";

interface MatrixInputProps {
  size: number;
  matrixValues: string[][];
  onValueChange: (row: number, col: number, value: string) => void;
}

export default function MatrixInput({ size, matrixValues, onValueChange }: MatrixInputProps) {
  return (
    <div
      className="grid gap-4 max-w-[500px] mx-auto mb-8 relative p-4"
      style={{ gridTemplateColumns: `repeat(${size}, 1fr)` }}
    >
      {/* Brackets */}
      <div className="absolute top-0 bottom-0 left-0 w-[10px] border-2 border-r-0 border-slate-400 rounded-l-md pointer-events-none"></div>
      <div className="absolute top-0 bottom-0 right-0 w-[10px] border-2 border-l-0 border-slate-400 rounded-r-md pointer-events-none"></div>
      
      {Array.from({ length: size }).map((_, i) =>
        Array.from({ length: size }).map((_, j) => (
          <input
            key={`a${i}${j}`}
            type="number"
            step="any"
            value={matrixValues[i]?.[j] || ""}
            onChange={(e) => onValueChange(i, j, e.target.value)}
            placeholder={`a${i + 1}${j + 1}`}
            className="w-full min-w-0 bg-slate-900/60 border border-white/10 text-slate-50 font-mono text-lg text-center p-3 rounded-lg outline-none transition-all focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20"
          />
        ))
      )}
    </div>
  );
}
