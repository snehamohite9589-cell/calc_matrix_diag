"use client";

import React, { useState } from "react";
import MatrixInput from "@/components/MatrixInput";
import ResultsDisplay from "@/components/ResultsDisplay";
import { MathJaxContext } from "better-react-mathjax";

export default function Home() {
  const [size, setSize] = useState(3);
  const [matrixValues, setMatrixValues] = useState<string[][]>(Array(3).fill(Array(3).fill("")));
  const [results, setResults] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSizeChange = (newSize: number) => {
    if (newSize < 2) newSize = 2;
    if (newSize > 10) newSize = 10;
    setSize(newSize);
    
    // Resize matrix but keep existing values where possible
    const newMatrix = Array.from({ length: newSize }, (_, i) =>
      Array.from({ length: newSize }, (_, j) => matrixValues[i]?.[j] || "")
    );
    setMatrixValues(newMatrix);
    setResults(null);
  };

  const handleValueChange = (row: number, col: number, value: string) => {
    const newMatrix = [...matrixValues.map(r => [...r])];
    newMatrix[row][col] = value;
    setMatrixValues(newMatrix);
  };

  const loadExample = (values: string[]) => {
    const n = Math.sqrt(values.length);
    setSize(n);
    const newMatrix = Array.from({ length: n }, (_, i) =>
      Array.from({ length: n }, (_, j) => values[i * n + j])
    );
    setMatrixValues(newMatrix);
    setResults(null);
  };

  const calculateDiagonalization = async () => {
    // Validate
    for (let i = 0; i < size; i++) {
      for (let j = 0; j < size; j++) {
        if (matrixValues[i][j] === "") {
          setError(`Please fill in all matrix elements (missing a${i + 1}${j + 1})`);
          return;
        }
      }
    }
    
    setError("");
    setLoading(true);
    setResults(null);

    try {
      const apiUrl = process.env.NEXT_PUBLIC_API_URL || "https://diagoanlization-calc.onrender.com";
      const response = await fetch(`${apiUrl}/api/diagonalize`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ matrix: matrixValues }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Failed to calculate");
      setResults(data);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <MathJaxContext>
      <div className="min-h-screen bg-slate-950 text-slate-50 font-sans p-8">
        <div className="max-w-4xl mx-auto space-y-8">
          
          <header className="text-center space-y-4">
            <h1 className="text-4xl md:text-5xl font-extrabold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
              Matrix Diagonalization
            </h1>
            <p className="text-slate-400 text-lg">
              Compute eigenvalues, eigenvectors, and diagonalize m × m matrices
            </p>
          </header>

          <main className="space-y-8">
            <section className="bg-slate-900/50 backdrop-blur-xl border border-white/10 rounded-2xl p-6 md:p-8 shadow-2xl">
              
              <div className="flex justify-between items-center bg-slate-900/40 p-4 rounded-xl border border-white/5 mb-8">
                <label htmlFor="matrix-size" className="font-semibold text-cyan-400">
                  Matrix Size (m × m):
                </label>
                <input
                  type="number"
                  id="matrix-size"
                  min="2"
                  max="10"
                  value={size}
                  onChange={(e) => handleSizeChange(parseInt(e.target.value) || 2)}
                  className="bg-slate-800 border border-cyan-500/50 text-white w-20 text-center py-2 rounded-lg outline-none focus:border-cyan-400"
                />
              </div>

              <h2 className="text-2xl font-bold mb-6 border-b border-white/10 pb-4">Enter Matrix</h2>
              
              <MatrixInput 
                size={size} 
                matrixValues={matrixValues} 
                onValueChange={handleValueChange} 
              />

              <div className="text-center mb-8">
                <p className="text-slate-400 mb-4 text-sm">Or try an example:</p>
                <div className="flex flex-wrap justify-center gap-3">
                  <button onClick={() => loadExample(["1", "0", "0", "0", "2", "0", "0", "0", "3"])} className="px-4 py-2 rounded-lg border border-white/10 hover:bg-white/5 transition-colors text-sm">Diagonal</button>
                  <button onClick={() => loadExample(["4", "1", "-1", "2", "5", "-2", "1", "1", "2"])} className="px-4 py-2 rounded-lg border border-white/10 hover:bg-white/5 transition-colors text-sm">Matrix 1</button>
                  <button onClick={() => loadExample(["2", "-1", "1", "-1", "2", "-1", "1", "-1", "2"])} className="px-4 py-2 rounded-lg border border-white/10 hover:bg-white/5 transition-colors text-sm">Symmetric</button>
                </div>
              </div>

              <button
                onClick={calculateDiagonalization}
                disabled={loading}
                className="w-full py-4 rounded-xl font-bold text-lg bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 transition-all shadow-lg shadow-cyan-500/20 disabled:opacity-50"
              >
                {loading ? "Computing..." : "Calculate Diagonalization"}
              </button>

              {error && (
                <div className="mt-6 p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-center">
                  {error}
                </div>
              )}

            </section>

            {results && (
              <section className="bg-slate-900/50 backdrop-blur-xl border border-white/10 rounded-2xl p-6 md:p-8 shadow-2xl">
                <h2 className="text-2xl font-bold border-b border-white/10 pb-4">Results</h2>
                <ResultsDisplay data={results} />
              </section>
            )}
          </main>

        </div>
      </div>
    </MathJaxContext>
  );
}
